import os
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
import joblib

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.abspath(os.path.join(base_dir, '..', 'data', 'features.csv'))
    model_path = os.path.join(base_dir, 'arima_model.pkl')

    df = pd.read_csv(data_path, index_col=0, parse_dates=True)
    print("Columns in features.csv:", df.columns.tolist())
    print(df.head())
    print(df.shape)

    # Use 'Global_active_power' as the target series
    series = df['Global_active_power']

    split = int(len(series) * 0.8)
    train = series.iloc[:split]

    model = ARIMA(train, order=(5, 1, 2)).fit()

    joblib.dump(model, model_path)
    print(f'ARIMA model saved to {model_path}')

if __name__ == '__main__':
    main()
