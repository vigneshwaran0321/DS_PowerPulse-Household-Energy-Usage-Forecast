import os
import pandas as pd

def preprocess_data(df):
    df['datetime'] = pd.to_datetime(df['datetime'])
    df.set_index('datetime', inplace=True)
    
    series = df['Global_active_power'].resample('h').mean().ffill()  # ✅ fix future warning
    cleaned_df = series.to_frame()

    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.abspath(os.path.join(base_dir, '..', 'data'))

    cleaned_path = os.path.join(data_dir, 'cleaned.csv')
    cleaned_df.to_csv(cleaned_path)

    print(f'Cleaned series saved to {cleaned_path}')
    return cleaned_df
