import os
import pandas as pd

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.abspath(os.path.join(base_dir, '..', 'data'))
    raw_path = os.path.join(data_dir, 'raw.csv')
    cleaned_path = os.path.join(data_dir, 'cleaned.csv')

    df = pd.read_csv(raw_path, sep=',', low_memory=False)
    print(f"Columns in raw data: {df.columns.tolist()}")
    print(df.head())

    # Combine 'datetime' (date part) + 'Time' (time part) into a full datetime column
    df['datetime_full'] = pd.to_datetime(
        df['datetime'] + ' ' + df['Time'], 
        format='%d/%m/%Y %H:%M:%S', 
        errors='coerce'
    )

    # Drop rows where datetime conversion failed
    df = df.dropna(subset=['datetime_full'])

    # Set this combined datetime as the index
    df.set_index('datetime_full', inplace=True)

    # Drop the original 'datetime' and 'Time' columns as they are no longer needed
    df.drop(columns=['datetime', 'Time'], inplace=True)

    # Convert all other columns to numeric, coercing errors
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # Resample hourly by taking mean
    df = df.resample('H').mean()

    # Drop rows that are all NaN
    df.dropna(how='all', inplace=True)

    # Ensure output directory exists
    os.makedirs(data_dir, exist_ok=True)

    # Save cleaned data
    df.to_csv(cleaned_path)
    print(f'✅ Cleaned data saved to: {cleaned_path}')

if __name__ == '__main__':
    main()
