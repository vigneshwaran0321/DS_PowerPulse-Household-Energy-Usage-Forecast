import os
import pandas as pd

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.abspath(os.path.join(base_dir, '..', 'data', 'cleaned.csv'))
    features_path = os.path.abspath(os.path.join(base_dir, '..', 'data', 'features.csv'))

    # Read time series data correctly
    series = pd.read_csv(data_path, index_col=0, parse_dates=True).squeeze()
    df = pd.DataFrame(series, columns=['Global_active_power'])

    for lag in [1, 24, 168]:
        df[f'lag_{lag}'] = df['Global_active_power'].shift(lag)

    df['roll_mean_24'] = df['Global_active_power'].rolling(24).mean()
    df['roll_std_24'] = df['Global_active_power'].rolling(24).std()

    df.dropna().to_csv(features_path)
    print(f'Features saved to {features_path}')
    

    print(series.head())

if __name__ == '__main__':
    main()
