import pandas as pd
import numpy as np
import joblib
import os
from sklearn.metrics import mean_absolute_error, mean_squared_error

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    clean_csv = os.path.abspath(os.path.join(base_dir, '..', 'data', 'cleaned.csv'))
    features_csv = os.path.abspath(os.path.join(base_dir, '..', 'data', 'features.csv'))
    arima_path = os.path.abspath(os.path.join(base_dir, 'arima_model.pkl'))
    rf_path = os.path.abspath(os.path.join(base_dir, 'rf_model.pkl'))

    series = pd.read_csv(clean_csv, parse_dates=['datetime_full'], index_col='datetime_full').squeeze()
    df = pd.read_csv(features_csv, parse_dates=['datetime_full'], index_col='datetime_full')

    split = int(len(df)*0.8)
    X_test = df.drop('Global_active_power',axis=1).iloc[split:]
    y_test = df['Global_active_power'].iloc[split:]

    arima = joblib.load(arima_path)
    rf = joblib.load(rf_path)

    arima_pred = arima.forecast(steps=len(y_test))
    rf_pred = rf.predict(X_test)

    for name, pred in [('ARIMA', arima_pred), ('RF', rf_pred)]:
        mae = mean_absolute_error(y_test, pred)
        rmse = np.sqrt(mean_squared_error(y_test, pred))
        print(f"{name} MAE: {mae:.4f}, RMSE: {rmse:.4f}")

if __name__ == '__main__':
    main()
