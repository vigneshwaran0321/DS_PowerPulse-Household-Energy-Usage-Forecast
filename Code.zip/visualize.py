# src/visualize.py

import os
import pandas as pd
import matplotlib.pyplot as plt

# Set backend explicitly for VS Code GUI
import matplotlib
matplotlib.use('TkAgg')  # or 'Qt5Agg' if TkAgg fails

# === Plot Functions ===

def plot_time_series(series, title='Time Series', ylabel='Value', xlabel='Time', filename='time_series.png'):
    plt.figure(figsize=(15, 5))
    plt.plot(series, label='Series')
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xlabel(xlabel)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()

    # Save the image
    output_dir = os.path.join(os.path.dirname(__file__), '..', 'outputs')
    os.makedirs(output_dir, exist_ok=True)
    save_path = os.path.join(output_dir, filename)
    plt.savefig(save_path)

    print(f"✅ Saved plot to {save_path}")
    plt.show(block=True)  # Keeps the window open


def plot_predictions(actual, predicted, title='Actual vs Predicted', filename='predictions.png'):
    plt.figure(figsize=(15, 5))
    plt.plot(actual.index, actual.values, label='Actual', linewidth=2)
    plt.plot(predicted.index, predicted.values, label='Predicted', linestyle='--')
    plt.title(title)
    plt.ylabel('Global Active Power')
    plt.xlabel('Time')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()

    # Save the image
    output_dir = os.path.join(os.path.dirname(__file__), '..', 'outputs')
    os.makedirs(output_dir, exist_ok=True)
    save_path = os.path.join(output_dir, filename)
    plt.savefig(save_path)

    print(f"✅ Saved prediction plot to {save_path}")
    plt.show(block=True)


# === Main Entry ===

def main():
    base_dir = os.path.dirname(os.path.dirname(__file__))
    cleaned_path = os.path.join(base_dir, 'data', 'cleaned.csv')
    features_path = os.path.join(base_dir, 'data', 'features.csv')

    if os.path.exists(cleaned_path):
        df = pd.read_csv(cleaned_path, parse_dates=['datetime_full'], index_col='datetime_full')
        plot_time_series(
            df['Global_active_power'],
            title='Cleaned Power Consumption Time Series',
            ylabel='Power (kW)',
            filename='cleaned_timeseries.png'
        )

    if os.path.exists(features_path):
        feat_df = pd.read_csv(features_path, parse_dates=['datetime_full'], index_col='datetime_full')
        plot_time_series(
            feat_df['Global_active_power'],
            title='Feature Dataset - Global Active Power',
            filename='features_timeseries.png'
        )


if __name__ == '__main__':
    main()
