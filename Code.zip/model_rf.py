import os
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import joblib

# Debug: Log all CSV files being read to trace issues
original_read_csv = pd.read_csv

def debug_read_csv(*args, **kwargs):
    file_path = args[0] if args else kwargs.get('filepath_or_buffer', '')
    print(f"[DEBUG] Reading CSV: {file_path}")
    return original_read_csv(*args, **kwargs)

pd.read_csv = debug_read_csv  # Monkey patch for debug

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))  # /home/prank/Documents/DataScience/DS_PowerPulse/src
    data_dir = os.path.abspath(os.path.join(base_dir, '..', 'data'))  # ../data

    features_path = os.path.join(data_dir, 'features.csv')
    model_path = os.path.join(base_dir, 'rf_model.pkl')

    print(f"[INFO] Looking for features file at: {features_path}")
    print(f"[INFO] Saving model to: {model_path}")

    if not os.path.exists(features_path):
        raise FileNotFoundError(f"[ERROR] Features file not found: {features_path}")

    df = pd.read_csv(features_path, parse_dates=['datetime_full'], index_col='datetime_full')
    
    if 'Global_active_power' not in df.columns:
        raise ValueError("[ERROR] 'power' column not found in features data.")

    X = df.drop(columns='Global_active_power')
    y = df['Global_active_power']

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)

    joblib.dump(model, model_path)
    print(f"[SUCCESS] Random Forest model saved to {model_path}")

if __name__ == '__main__':
    main()
