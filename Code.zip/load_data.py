# src/load_raw.py
import os
import pandas as pd

def load_raw_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.abspath(os.path.join(base_dir, '..', 'data'))
    raw_path = os.path.join(data_dir, 'raw.csv')

    # Make sure data directory exists
    os.makedirs(data_dir, exist_ok=True)

    # Load from text file
    txt_path = os.path.join(data_dir, 'household_power_consumption.txt')
    df = pd.read_csv(txt_path, sep=';', low_memory=False)

    # Fix columns (optional)
    df.columns = ['datetime'] + list(df.columns[1:])

    df.to_csv(raw_path, index=False)
    print(f'Raw data saved to: {raw_path}')
    print(df.head())
    return df

if __name__ == "__main__":
    load_raw_data()
