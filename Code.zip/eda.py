import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose

def run_eda():
    series = pd.read_csv('data/cleaned.csv', parse_dates=['dt'], index_col='dt').squeeze()
    series.plot(title='Hourly Power')
    plt.show()
    decomp = seasonal_decompose(series, period=24)
    decomp.plot()
    plt.show()

if __name__=='__main__':
    run_eda()